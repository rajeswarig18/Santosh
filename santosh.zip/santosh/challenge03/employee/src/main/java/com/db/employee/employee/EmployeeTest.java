package com.db.employee.employee;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class EmployeeTest {

	@LocalServerPort
	int randomServerPort;

	@Test
	public void testGetEmployeeListSuccess() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:" + randomServerPort + "ap1/v1/employee/getEmployess";
		URI uri = new URI(baseUrl);

		ResponseEntity<Employee> result = restTemplate.getForEntity(uri, Employee.class);

		// Verify request succeed
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(true, result.getBody().contains("employeeList"));
	}

}
